/**
 * Flash Loan Arbitrage Scanner — Base Chain
 *
 * Estratégia: Empresta do Aave V3 (0.05% fee), arbitra entre DEXes na Base,
 * devolve na mesma transação. Capital necessário: $0. Risco: apenas gas (~$0.01-0.05).
 *
 * Fluxo atómico:
 *   1. Aave.flashLoan(asset, amount) → recebe tokens
 *   2. Swap no DEX barato (compra)
 *   3. Swap no DEX caro (vende)
 *   4. Repaga Aave (amount + 0.05%)
 *   5. Lucro fica na wallet
 *   Se passo 2-4 falhar → tx reverte → só perde gas
 */

import { supabaseAdmin } from '@/lib/supabase'

// ─── Constantes ─────────────────────────────────────────────────────────────

const AAVE_FLASH_LOAN_FEE_PCT = 0.05  // Aave V3: 0.05% do montante emprestado
const BASE_GAS_COST_USD = 0.03        // Gas médio em Base por tx complexa
const FLASH_LOAN_GAS_USD = 0.08       // Gas estimado para flash loan inteiro (3 swaps + callback)
const MIN_PROFIT_USD = 0.05           // Lucro mínimo para valer a pena ($0.05)
const MIN_EDGE_PCT = 0.15            // Edge mínimo após todas as taxas (0.15%)
const MAX_LOAN_USD = 50000           // Máximo por flash loan (liquidez típica)
const MIN_LOAN_USD = 100             // Mínimo para o lucro cobrir gas

// DEXes na Base com deploy confirmado
const BASE_DEXES = {
  aerodrome:  { name: 'Aerodrome',  feePct: 0.05, router: '0xcF77a3Ba9A5CA399B7c97c74d54e5b1Beb874E43' },
  uniswapV3:  { name: 'Uniswap V3', feePct: 0.05, router: '0x2626664c2603336E57B271c5C0b26F421741e481' },
  sushiswap:  { name: 'SushiSwap',  feePct: 0.05, router: '0x6BDED42c6DA8FBf0d2bA55B2fa120B529F6c7b2a' },
  baseswap:   { name: 'BaseSwap',   feePct: 0.05, router: '0x327Df1E6de05895d2ab08513aaDD9313Fe505d86' },
} as const

// Tokens na Base com liquidez significativa para flash loans
const BASE_TOKENS = {
  WETH:   { address: '0x4200000000000000000000000000000000000006', decimals: 18, symbol: 'WETH'   },
  USDC:   { address: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913', decimals: 6,  symbol: 'USDC'   },
  USDT:   { address: '0xfde4C96c8593536E31F229EA8f37b2ADa2699bb2', decimals: 6,  symbol: 'USDT'   },
  DAI:    { address: '0x50c5725949A6F0c72E6C4a641F24049A917DB0Cb', decimals: 18, symbol: 'DAI'    },
  cbETH:  { address: '0x2Ae3F1Ec7F1F5012CFEab0185bfc7aa3cf0DEc22', decimals: 18, symbol: 'cbETH'  },
  weETH:  { address: '0x04C0599Ae5A44757c0af6F9eC3b93da8976c150A', decimals: 18, symbol: 'weETH'  },
  rETH:   { address: '0xB6fe221Fe9EeF5aBa221c348bA20A1Bf5e73624c', decimals: 18, symbol: 'rETH'   },
  AERO:   { address: '0x940181a94A35A4569E4529A3DF544B55D777367F', decimals: 18, symbol: 'AERO'   },
  VELVET: { address: '0x6b9bb36519538e0C8b9Ae4156eC1a4F3F4e6c4Be', decimals: 18, symbol: 'VELVET' },
} as const

// Pares com alta probabilidade de spread (LSTs + stablecoins + tokens Base)
const FLASH_LOAN_PAIRS: { borrow: keyof typeof BASE_TOKENS; intermediate: keyof typeof BASE_TOKENS; label: string }[] = [
  // Stablecoin triangular — empresta USDC, compra DAI barato, vende DAI caro
  { borrow: 'USDC', intermediate: 'DAI',    label: 'USDC→DAI' },
  { borrow: 'USDC', intermediate: 'USDT',   label: 'USDC→USDT' },
  { borrow: 'USDT', intermediate: 'DAI',    label: 'USDT→DAI' },

  // LST arbitrage — empresta WETH, compra LST barato, vende LST caro
  { borrow: 'WETH', intermediate: 'cbETH',  label: 'WETH→cbETH' },
  { borrow: 'WETH', intermediate: 'weETH',  label: 'WETH→weETH' },
  { borrow: 'WETH', intermediate: 'rETH',   label: 'WETH→rETH' },

  // LST cross-rate
  { borrow: 'cbETH', intermediate: 'weETH', label: 'cbETH→weETH' },
  { borrow: 'cbETH', intermediate: 'rETH',  label: 'cbETH→rETH' },
  { borrow: 'weETH', intermediate: 'rETH',  label: 'weETH→rETH' },

  // Token Base — alta volatilidade = mais spreads
  { borrow: 'WETH', intermediate: 'AERO',   label: 'WETH→AERO' },
  { borrow: 'USDC', intermediate: 'AERO',   label: 'USDC→AERO' },

  // WETH via stablecoins
  { borrow: 'USDC', intermediate: 'WETH',   label: 'USDC→WETH' },
]

// ─── Tipos ──────────────────────────────────────────────────────────────────

export interface FlashLoanOpportunity {
  id: string
  borrowToken: string
  borrowAddress: string
  borrowDecimals: number
  intermediateToken: string
  intermediateAddress: string
  intermediateDecimals: number
  dexBuy: string
  dexSell: string
  priceBuy: number   // preço do intermediate em termos do borrow (compra)
  priceSell: number  // preço do intermediate em termos do borrow (venda)
  spreadPct: number  // spread bruto entre DEXes (%)
  loanAmountUSD: number
  aaveFeeUSD: number
  gasCostUSD: number
  slippageEstPct: number
  netEdgePct: number
  netProfitUSD: number
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
  timestamp: string
}

export interface FlashLoanScanResult {
  opportunities: FlashLoanOpportunity[]
  totalPairs: number
  dexCalls: number
  elapsedMs: number
  timestamp: string
}

// ─── DexScreener API ────────────────────────────────────────────────────────

interface DexScreenerPair {
  chainId: string
  dexId: string
  pairAddress: string
  baseToken: { address: string; symbol: string }
  quoteToken: { address: string; symbol: string }
  priceNative: string
  priceUsd: string
  volume: { h24: number; h1: number }
  liquidity: { usd: number }
  fdv: number
}

async function fetchBasePairs(
  tokenA: string,
  tokenB: string
): Promise<DexScreenerPair[]> {
  const url = `https://api.dexscreener.com/latest/dex/tokens/${tokenA},${tokenB}`
  const res = await fetch(url, { signal: AbortSignal.timeout(12000) })
  if (!res.ok) throw new Error(`DexScreener ${res.status}`)

  const json = await res.json()
  const pairs: DexScreenerPair[] = json.pairs ?? []

  // Filtrar: só Base chain, DEXes aceites, liquidez mínima
  const acceptedDexIds = new Set([
    'aerodrome', 'aerodrome-v2', 'aerodrome-cl',
    'uniswap', 'uniswap-v3',
    'sushiswap', 'sushiswap-v3',
    'baseswap',
  ])

  const addrALow = tokenA.toLowerCase()
  const addrBLow = tokenB.toLowerCase()

  return pairs.filter(p => {
    if (p.chainId !== 'base') return false
    if (!acceptedDexIds.has(p.dexId)) return false
    if ((p.liquidity?.usd ?? 0) < 5000) return false  // Mínimo $5k liquidez
    const base = p.baseToken.address.toLowerCase()
    const quote = p.quoteToken.address.toLowerCase()
    return (base === addrALow && quote === addrBLow) ||
           (base === addrBLow && quote === addrALow)
  })
}

// ─── Cálculos ───────────────────────────────────────────────────────────────

function estimateSlippage(liquidityUSD: number, tradeSizeUSD: number): number {
  // Modelo linear conservador: slippage aumenta com trade size / liquidez
  const impactRatio = tradeSizeUSD / Math.max(liquidityUSD, 1000)
  // Para pools grandes, impacto é menor; para pequenos, maior
  const baseSlippage = impactRatio * 100 // percentagem
  return Math.min(baseSlippage * 2, 5.0) // 2x safety margin, cap 5%
}

function estimateLoanSize(borrowToken: string, intermediateToken: string): number {
  // Tamanho óptimo do loan: equilíbrio entre lucro e slippage
  // Para stablecoins: empresta mais (baixo slippage)
  // Para LSTs: empresta moderado
  // Para tokens voláteis: empresta menos (alto slippage)

  const stablecoins = new Set(['USDC', 'USDT', 'DAI'])
  const lsts = new Set(['cbETH', 'weETH', 'rETH'])

  if (stablecoins.has(borrowToken) && stablecoins.has(intermediateToken)) return 20000
  if (stablecoins.has(borrowToken) && lsts.has(intermediateToken)) return 10000
  if (lsts.has(borrowToken) && lsts.has(intermediateToken)) return 8000
  if (lsts.has(borrowToken) || stablecoins.has(borrowToken)) return 5000
  return 2000  // Tokens voláteis
}

function deduplicateByDex(pairs: DexScreenerPair[]): Map<string, DexScreenerPair> {
  // Por DEX, manter o par com mais liquidez
  const byDex = new Map<string, DexScreenerPair>()
  for (const p of pairs) {
    const existing = byDex.get(p.dexId)
    if (!existing || (p.liquidity?.usd ?? 0) > (existing.liquidity?.usd ?? 0)) {
      byDex.set(p.dexId, p)
    }
  }
  return byDex
}

// ─── Scanner Principal ──────────────────────────────────────────────────────

export async function scanFlashLoanOpportunities(): Promise<FlashLoanScanResult> {
  const start = Date.now()
  const opportunities: FlashLoanOpportunity[] = []
  let totalPairs = 0
  let dexCalls = 0

  for (const pair of FLASH_LOAN_PAIRS) {
    const tokenA = BASE_TOKENS[pair.borrow]
    const tokenB = BASE_TOKENS[pair.intermediate]
    if (!tokenA || !tokenB) continue

    let dexPairs: DexScreenerPair[]
    try {
      dexPairs = await fetchBasePairs(tokenA.address, tokenB.address)
      dexCalls++
    } catch (err) {
      console.warn(`[flash-loan] ${pair.label}: ${(err as Error).message}`)
      continue
    }

    totalPairs += dexPairs.length

    // Agrupar por DEX (manter mais líquido por DEX)
    const byDex = deduplicateByDex(dexPairs)

    if (byDex.size < 2) continue  // Precisa de pelo menos 2 DEXes para arbitrar

    const loanAmountUSD = estimateLoanSize(pair.borrow, pair.intermediate)

    // Comparar todos os pares de DEXes
    const dexEntries = Array.from(byDex.entries())

    for (let i = 0; i < dexEntries.length; i++) {
      for (let j = i + 1; j < dexEntries.length; j++) {
        const [dexIdA, dexPairA] = dexEntries[i]
        const [dexIdB, dexPairB] = dexEntries[j]

        // Normalizar preços: sempre em termos de borrow/intermediate
        const baseIsBorrowA = dexPairA.baseToken.address.toLowerCase() === tokenA.address.toLowerCase()
        const baseIsBorrowB = dexPairB.baseToken.address.toLowerCase() === tokenA.address.toLowerCase()

        // Preço = quantos tokens borrow por 1 token intermediate
        const priceNativeA = parseFloat(dexPairA.priceNative)
        const priceNativeB = parseFloat(dexPairB.priceNative)

        if (!isFinite(priceNativeA) || !isFinite(priceNativeB) || priceNativeA <= 0 || priceNativeB <= 0) continue

        // Converter para preço uniforme: borrow por intermediate
        const priceA = baseIsBorrowA ? (1 / priceNativeA) : priceNativeA
        const priceB = baseIsBorrowB ? (1 / priceNativeB) : priceNativeB

        if (!isFinite(priceA) || !isFinite(priceB) || priceA <= 0 || priceB <= 0) continue

        // Comprar no barato (preço menor), vender no caro (preço maior)
        const [dexBuy, dexSell, priceBuy, priceSell] = priceA < priceB
          ? [dexIdA, dexIdB, priceA, priceB]
          : [dexIdB, dexIdA, priceB, priceA]

        // Spread bruto
        const spreadPct = ((priceSell - priceBuy) / priceBuy) * 100

        if (spreadPct <= 0) continue

        // Taxas
        const aaveFeeUSD = loanAmountUSD * (AAVE_FLASH_LOAN_FEE_PCT / 100)
        const gasCostUSD = FLASH_LOAN_GAS_USD

        // Slippage estimado (usa liquidez do DEX menor)
        const minLiquidity = Math.min(dexPairA.liquidity?.usd ?? 0, dexPairB.liquidity?.usd ?? 0)
        const slippagePct = estimateSlippage(minLiquidity, loanAmountUSD)

        // DEX trading fees (compra + venda)
        const dexBuyFee = Object.values(BASE_DEXES).find(d => dexBuy.startsWith(d.name.toLowerCase()))?.feePct ?? 0.05
        const dexSellFee = Object.values(BASE_DEXES).find(d => dexSell.startsWith(d.name.toLowerCase()))?.feePct ?? 0.05
        const totalDexFeePct = dexBuyFee + dexSellFee

        // Edge líquido
        const totalCostsPct = AAVE_FLASH_LOAN_FEE_PCT + slippagePct + totalDexFeePct
        const netEdgePct = spreadPct - totalCostsPct

        // Lucro em USD
        const netProfitUSD = (netEdgePct / 100) * loanAmountUSD - gasCostUSD

        // Filtrar oportunidades não lucrativas
        if (netEdgePct < MIN_EDGE_PCT || netProfitUSD < MIN_PROFIT_USD) continue

        // Confidence baseado em liquidez e spread
        const confidence: 'HIGH' | 'MEDIUM' | 'LOW' =
          minLiquidity > 100000 && spreadPct > 0.5 ? 'HIGH' :
          minLiquidity > 30000 && spreadPct > 0.3 ? 'MEDIUM' : 'LOW'

        opportunities.push({
          id: `FL_${pair.borrow}_${pair.intermediate}_${dexBuy}_${dexSell}_${Date.now()}`,
          borrowToken: pair.borrow,
          borrowAddress: tokenA.address,
          borrowDecimals: tokenA.decimals,
          intermediateToken: pair.intermediate,
          intermediateAddress: tokenB.address,
          intermediateDecimals: tokenB.decimals,
          dexBuy,
          dexSell,
          priceBuy,
          priceSell,
          spreadPct: parseFloat(spreadPct.toFixed(4)),
          loanAmountUSD,
          aaveFeeUSD: parseFloat(aaveFeeUSD.toFixed(2)),
          gasCostUSD: parseFloat(gasCostUSD.toFixed(2)),
          slippageEstPct: parseFloat(slippagePct.toFixed(3)),
          netEdgePct: parseFloat(netEdgePct.toFixed(4)),
          netProfitUSD: parseFloat(netProfitUSD.toFixed(4)),
          confidence,
          timestamp: new Date().toISOString(),
        })
      }
    }
  }

  // Ordenar por lucro líquido decrescente
  opportunities.sort((a, b) => b.netProfitUSD - a.netProfitUSD)

  // Persistir no Supabase
  if (opportunities.length > 0) {
    const rows = opportunities.map(o => ({
      borrowToken:      o.borrowToken,
      intermediateToken: o.intermediateToken,
      dexBuy:           o.dexBuy,
      dexSell:          o.dexSell,
      spreadPct:        o.spreadPct,
      loanAmountUSD:    o.loanAmountUSD,
      aaveFeeUSD:       o.aaveFeeUSD,
      gasCostUSD:       o.gasCostUSD,
      slippageEstPct:   o.slippageEstPct,
      netEdgePct:       o.netEdgePct,
      netProfitUSD:     o.netProfitUSD,
      confidence:       o.confidence,
      status:           'DETECTED',
    }))

    const { error } = await supabaseAdmin.from('FlashLoanOpportunity').insert(rows)
    if (error) console.error('[flash-loan] db insert error:', error.message)
  }

  const elapsedMs = Date.now() - start
  const profitable = opportunities.filter(o => o.netProfitUSD > MIN_PROFIT_USD)

  console.log(
    `[flash-loan] ${opportunities.length} oportunidades | ` +
    `${profitable.length} lucrativas | ` +
    `${totalPairs} pares de ${dexCalls} chamadas | ` +
    `${elapsedMs}ms`
  )

  if (profitable.length > 0) {
    profitable.slice(0, 5).forEach(o => console.log(
      `  💰 ${o.borrowToken}→${o.intermediateToken} ${o.dexBuy}→${o.dexSell} ` +
      `spread=${o.spreadPct.toFixed(2)}% edge=${o.netEdgePct.toFixed(2)}% ` +
      `profit=$${o.netProfitUSD.toFixed(2)} loan=$${o.loanAmountUSD}`
    ))
  }

  return {
    opportunities,
    totalPairs,
    dexCalls,
    elapsedMs,
    timestamp: new Date().toISOString(),
  }
}

// ─── Histórico & Métricas ───────────────────────────────────────────────────

export async function getRecentFlashLoanOpportunities(hours = 24, limit = 50) {
  const since = new Date(Date.now() - hours * 3600_000).toISOString()
  const { data, error } = await supabaseAdmin
    .from('FlashLoanOpportunity')
    .select('*')
    .gte('createdAt', since)
    .order('netProfitUSD', { ascending: false })
    .limit(limit)

  if (error) {
    console.error('[flash-loan] fetch error:', error.message)
    return []
  }
  return data ?? []
}

export async function getFlashLoanMetrics(days = 7) {
  const since = new Date(Date.now() - days * 24 * 3600_000).toISOString()

  const { data, error } = await supabaseAdmin
    .from('FlashLoanOpportunity')
    .select('netEdgePct, netProfitUSD, confidence, borrowToken, intermediateToken, dexBuy, dexSell')
    .gte('createdAt', since)

  if (error || !data || data.length === 0) {
    return { totalDetected: 0, avgEdgePct: 0, avgProfitUSD: 0, topPair: null, topDexBuy: null, byConfidence: { HIGH: 0, MEDIUM: 0, LOW: 0 } }
  }

  const avgEdge = data.reduce((s, r) => s + r.netEdgePct, 0) / data.length
  const avgProfit = data.reduce((s, r) => s + r.netProfitUSD, 0) / data.length

  // Contar por par e DEX
  const pairCount: Record<string, number> = {}
  const dexCount: Record<string, number> = {}
  const confCount: Record<string, number> = { HIGH: 0, MEDIUM: 0, LOW: 0 }

  for (const r of data) {
    const pairKey = `${r.borrowToken}→${r.intermediateToken}`
    pairCount[pairKey] = (pairCount[pairKey] ?? 0) + 1
    dexCount[r.dexBuy] = (dexCount[r.dexBuy] ?? 0) + 1
    confCount[r.confidence] = (confCount[r.confidence] ?? 0) + 1
  }

  const topPair = Object.entries(pairCount).sort((a, b) => b[1] - a[1])[0]?.[0] ?? null
  const topDexBuy = Object.entries(dexCount).sort((a, b) => b[1] - a[1])[0]?.[0] ?? null

  return {
    totalDetected: data.length,
    avgEdgePct: parseFloat(avgEdge.toFixed(4)),
    avgProfitUSD: parseFloat(avgProfit.toFixed(4)),
    topPair,
    topDexBuy,
    byConfidence: confCount,
  }
}

// ─── Simulador de Paper Trading ─────────────────────────────────────────────

export interface FlashLoanPaperTrade {
  id: string
  opportunity: FlashLoanOpportunity
  status: 'detected' | 'simulated' | 'expired'
  simulatedProfitUSD: number | null
  detectedAt: string
  expiredAt: string | null
}

export async function createFlashLoanPaperTrade(
  opportunity: FlashLoanOpportunity
): Promise<void> {
  // Simular execução: o profit real seria o netProfitUSD calculado
  // Na prática, o MEV/sandwich attack pode reduzir o lucro real
  const mevDiscount = 0.7  // Assumir que 30% do edge é capturado por MEV
  const simulatedProfit = opportunity.netProfitUSD * mevDiscount

  const { error } = await supabaseAdmin.from('FlashLoanPaperTrade').insert({
    borrowToken:       opportunity.borrowToken,
    intermediateToken: opportunity.intermediateToken,
    dexBuy:            opportunity.dexBuy,
    dexSell:           opportunity.dexSell,
    spreadPct:         opportunity.spreadPct,
    loanAmountUSD:     opportunity.loanAmountUSD,
    netEdgePct:        opportunity.netEdgePct,
    netProfitUSD:      opportunity.netProfitUSD,
    simulatedProfitUSD: simulatedProfit,
    status:            'detected',
  })

  if (error) console.error('[flash-loan] paper trade error:', error.message)
}

export async function expireOldFlashLoanPaperTrades(): Promise<number> {
  // Fechar trades detectados há mais de 5 minutos (oportunidades de flash loan são efémeras)
  const cutoff = new Date(Date.now() - 5 * 60_000).toISOString()

  const { data, error } = await supabaseAdmin
    .from('FlashLoanPaperTrade')
    .update({ status: 'expired', expiredAt: new Date().toISOString() })
    .eq('status', 'detected')
    .lt('detectedAt', cutoff)

  if (error) {
    console.error('[flash-loan] expire error:', error.message)
    return 0
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const rows = data as any
  const updatedCount = Array.isArray(rows) ? rows.length : 0
  return updatedCount
}
