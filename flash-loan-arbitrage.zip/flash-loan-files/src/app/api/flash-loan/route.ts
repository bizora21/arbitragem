import { NextResponse } from 'next/server'
import { scanFlashLoanOpportunities, getRecentFlashLoanOpportunities, getFlashLoanMetrics } from '@/lib/strategies/flash-loan-scanner'

export const dynamic = 'force-dynamic'

// GET: Listar oportunidades recentes + métricas
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hours = parseInt(searchParams.get('hours') ?? '24') || 24
    const includeMetrics = searchParams.get('metrics') === 'true'

    const [opportunities, metrics] = await Promise.all([
      getRecentFlashLoanOpportunities(hours),
      includeMetrics ? getFlashLoanMetrics() : null,
    ])

    return NextResponse.json({
      data: {
        opportunities,
        metrics,
        strategy: 'FLASH_LOAN',
        chain: 'Base',
        capital: 0,
        risk: 'gas_only',
        gasEstimate: '$0.03-0.08 per tx',
      },
      timestamp: new Date().toISOString(),
    })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}

// POST: Forçar scan imediato
export async function POST() {
  try {
    const result = await scanFlashLoanOpportunities()

    return NextResponse.json({
      success: true,
      strategy: 'FLASH_LOAN',
      chain: 'Base',
      capital: 0,
      risk: 'gas_only',
      opportunities: result.opportunities.length,
      profitable: result.opportunities.filter(o => o.netProfitUSD > 0.05).length,
      topOpportunity: result.opportunities[0] ?? null,
      elapsedMs: result.elapsedMs,
      timestamp: result.timestamp,
    })
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error'
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
