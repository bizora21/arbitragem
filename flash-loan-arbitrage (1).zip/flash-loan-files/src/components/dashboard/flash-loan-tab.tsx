'use client'

import { useState, useEffect, useCallback } from 'react'
import { RefreshCw, AlertCircle, Zap, TrendingUp, Flame, ShieldCheck } from 'lucide-react'
import { StrategyValidationPanel } from './strategy-validation-panel'
import { CapitalBadge } from '@/components/CapitalBadge'
import { ReturnSimulator } from '@/components/ReturnSimulator'

interface FlashLoanOpp {
  borrowToken: string
  intermediateToken: string
  dexBuy: string
  dexSell: string
  spreadPct: number
  loanAmountUSD: number
  aaveFeeUSD: number
  gasCostUSD: number
  slippageEstPct: number
  netEdgePct: number
  netProfitUSD: number
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
  status: string
}

interface FlashLoanMetrics {
  totalDetected: number
  avgEdgePct: number
  avgProfitUSD: number
  topPair: string | null
  topDexBuy: string | null
  byConfidence: { HIGH: number; MEDIUM: number; LOW: number }
}

interface FlashLoanResult {
  data: {
    opportunities: FlashLoanOpp[]
    metrics: FlashLoanMetrics | null
    strategy: string
    chain: string
    capital: number
    risk: string
    gasEstimate: string
  }
  timestamp: string
}

interface ScanResult {
  success: boolean
  opportunities: number
  profitable: number
  topOpportunity: FlashLoanOpp | null
  elapsedMs: number
  timestamp: string
}

function ConfidenceBadge({ level }: { level: 'HIGH' | 'MEDIUM' | 'LOW' }) {
  const config = {
    HIGH:   { label: 'ALTA',  color: 'text-emerald-400 bg-emerald-400/10 border-emerald-500/30' },
    MEDIUM: { label: 'MÉDIA', color: 'text-yellow-400 bg-yellow-400/10 border-yellow-500/30' },
    LOW:    { label: 'BAIXA', color: 'text-red-400 bg-red-400/10 border-red-500/30' },
  }
  const c = config[level]
  return (
    <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${c.color}`}>
      {c.label}
    </span>
  )
}

function ProfitBadge({ profit }: { profit: number }) {
  const color = profit > 1 ? 'text-emerald-400' : profit > 0.3 ? 'text-yellow-400' : 'text-slate-400'
  return (
    <span className={`font-mono text-sm font-bold ${color}`}>
      ${profit.toFixed(2)}
    </span>
  )
}

function PairLabel({ borrow, intermediate }: { borrow: string; intermediate: string }) {
  return (
    <span className="font-semibold text-slate-200">
      {borrow}<span className="text-slate-500 mx-0.5">→</span>{intermediate}
    </span>
  )
}

function DexLabel({ name }: { name: string }) {
  const colors: Record<string, string> = {
    'aerodrome': 'text-blue-400 bg-blue-400/10 border-blue-500/30',
    'aerodrome-v2': 'text-blue-400 bg-blue-400/10 border-blue-500/30',
    'aerodrome-cl': 'text-blue-400 bg-blue-400/10 border-blue-500/30',
    'uniswap': 'text-pink-400 bg-pink-400/10 border-pink-500/30',
    'uniswap-v3': 'text-pink-400 bg-pink-400/10 border-pink-500/30',
    'sushiswap': 'text-orange-400 bg-orange-400/10 border-orange-500/30',
    'sushiswap-v3': 'text-orange-400 bg-orange-400/10 border-orange-500/30',
    'baseswap': 'text-cyan-400 bg-cyan-400/10 border-cyan-500/30',
  }
  const c = colors[name] ?? 'text-slate-400 bg-slate-400/10 border-slate-500/30'
  return (
    <span className={`text-xs px-2 py-0.5 rounded-full border ${c}`}>
      {name}
    </span>
  )
}

export function FlashLoanTab() {
  const [data, setData] = useState<FlashLoanResult | null>(null)
  const [scanResult, setScanResult] = useState<ScanResult | null>(null)
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [scanning, setScanning] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)

  const fetchData = useCallback(async (isRefresh = false) => {
    if (isRefresh) setRefreshing(true)
    else setLoading(true)

    try {
      const res = await fetch('/api/flash-loan?hours=24&metrics=true')
      const json = await res.json()
      setData(json)
    } catch {
      setData(null)
    }

    setLastUpdate(new Date())
    setLoading(false)
    setRefreshing(false)
  }, [])

  useEffect(() => {
    fetchData()
    const iv = setInterval(() => fetchData(true), 60_000)
    return () => clearInterval(iv)
  }, [fetchData])

  const handleScan = async () => {
    setScanning(true)
    try {
      const res = await fetch('/api/flash-loan', { method: 'POST' })
      const json = await res.json()
      setScanResult(json)
      // Refresh data after scan
      await fetchData(true)
    } catch {
      // ignore
    }
    setScanning(false)
  }

  const opportunities = data?.data?.opportunities ?? []
  const metrics = data?.data?.metrics ?? null
  const hasError = !data && !loading
  const profitable = opportunities.filter(o => o.netProfitUSD > 0.05)

  return (
    <div className="space-y-6">
      <StrategyValidationPanel
        strategy="FLASH_LOAN"
        label="Flash Loan Arbitrage — Base"
        icon="⚡"
        timestamp={data?.timestamp ?? null}
        loading={loading}
        error={hasError}
        opportunityCount={opportunities.length}
        bestValueLabel={profitable.length > 0 ? `Best: $${profitable[0].netProfitUSD.toFixed(2)}` : null}
        sources={['Aave V3', 'Aerodrome', 'Uniswap V3', 'DexScreener']}
        alerts={{
          urgent: opportunities.filter(o => o.confidence === 'HIGH').length,
          high: opportunities.filter(o => o.confidence === 'MEDIUM').length,
          medium: opportunities.filter(o => o.confidence === 'LOW').length,
        }}
        dataConfidence={opportunities.length > 0 ? 'HIGH' : 'MEDIUM'}
      />

      <div className="flex flex-wrap items-center gap-3">
        <CapitalBadge strategy="FLASH_LOAN" />
        <ReturnSimulator strategy="FLASH_LOAN" chain="Base" />
      </div>

      {/* Flash Loan Info Banner */}
      <div className="bg-purple-500/10 border border-purple-500/20 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <Zap className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-purple-300 font-semibold text-sm">Como funciona — $0 Capital, $0 Risco</p>
            <p className="text-slate-400 text-xs mt-1">
              Empresta tokens do Aave V3 (0.05% fee), compra no DEX barato, vende no DEX caro, devolve o empréstimo — tudo numa transacção atómica.
              Se a arbitragem não for lucrativa, a transacção reverte e só perdes gas (~$0.03-0.08 na Base).
              Nenhum capital próprio necessário.
            </p>
          </div>
        </div>
      </div>

      {/* Scan button */}
      <div className="flex items-center gap-3">
        <button
          onClick={handleScan}
          disabled={scanning}
          className="flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Flame className={`w-4 h-4 ${scanning ? 'animate-pulse' : ''}`} />
          {scanning ? 'Scanning...' : 'Forçar Scan Agora'}
        </button>
        {scanResult && (
          <span className="text-xs text-slate-500">
            {scanResult.opportunities} oportunidades · {scanResult.profitable} lucrativas · {scanResult.elapsedMs}ms
          </span>
        )}
      </div>

      {loading && (
        <div className="flex items-center justify-center py-16">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-slate-500 text-sm">A scannar oportunidades de flash loan na Base...</p>
            <p className="text-slate-600 text-xs mt-1">Aave V3 · Aerodrome · Uniswap V3 · DexScreener</p>
          </div>
        </div>
      )}

      {!loading && hasError && (
        <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-6 flex gap-3">
          <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-red-400 font-semibold">Erro ao carregar dados</p>
            <p className="text-red-300 text-sm mt-1">Verifica se as tabelas do Supabase foram criadas (flash_loan_tables.sql)</p>
          </div>
        </div>
      )}

      {!loading && !hasError && (
        <>
          {/* Stats strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-4">
              <p className="text-xs text-slate-500 mb-1">Oportunidades</p>
              <p className="text-2xl font-bold text-slate-200">{opportunities.length}</p>
            </div>
            <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-4">
              <p className="text-xs text-slate-500 mb-1">Lucrativas</p>
              <p className={`text-2xl font-bold ${profitable.length > 0 ? 'text-emerald-400' : 'text-slate-400'}`}>
                {profitable.length}
              </p>
            </div>
            <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-4">
              <p className="text-xs text-slate-500 mb-1">Melhor lucro</p>
              <p className="text-2xl font-bold text-emerald-400">
                {profitable.length > 0 ? `$${profitable[0].netProfitUSD.toFixed(2)}` : '—'}
              </p>
            </div>
            <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-4">
              <p className="text-xs text-slate-500 mb-1">Gas estimado</p>
              <p className="text-2xl font-bold text-slate-200">$0.08</p>
            </div>
          </div>

          {/* Metrics summary */}
          {metrics && metrics.totalDetected > 0 && (
            <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-4">
              <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-purple-400" />
                Métricas (últimos 7 dias)
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                <div>
                  <p className="text-slate-500">Total detectadas</p>
                  <p className="text-slate-200 font-semibold text-sm">{metrics.totalDetected}</p>
                </div>
                <div>
                  <p className="text-slate-500">Edge médio</p>
                  <p className="text-slate-200 font-semibold text-sm">{metrics.avgEdgePct.toFixed(2)}%</p>
                </div>
                <div>
                  <p className="text-slate-500">Lucro médio</p>
                  <p className="text-slate-200 font-semibold text-sm">${metrics.avgProfitUSD.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-slate-500">Top par</p>
                  <p className="text-slate-200 font-semibold text-sm">{metrics.topPair ?? '—'}</p>
                </div>
                <div>
                  <p className="text-slate-500">Confiança</p>
                  <p className="text-slate-200 font-semibold text-sm">
                    <span className="text-emerald-400">{metrics.byConfidence.HIGH}H</span>
                    {' '}
                    <span className="text-yellow-400">{metrics.byConfidence.MEDIUM}M</span>
                    {' '}
                    <span className="text-red-400">{metrics.byConfidence.LOW}L</span>
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Top opportunities cards */}
          {profitable.length > 0 && (
            <div>
              <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
                <Zap className="w-4 h-4 text-yellow-400" />
                Oportunidades lucrativas
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {profitable.slice(0, 9).map((opp, i) => (
                  <div key={i} className="bg-slate-800/60 border border-slate-700/50 rounded-xl p-4 hover:border-slate-600/50 transition-colors">
                    <div className="flex items-center justify-between mb-3">
                      <PairLabel borrow={opp.borrowToken} intermediate={opp.intermediateToken} />
                      <ConfidenceBadge level={opp.confidence} />
                    </div>

                    <div className="flex items-center gap-2 mb-3 text-xs">
                      <DexLabel name={opp.dexBuy} />
                      <span className="text-slate-600">→</span>
                      <DexLabel name={opp.dexSell} />
                    </div>

                    <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs mb-3">
                      <div>
                        <p className="text-slate-500">Spread</p>
                        <p className="text-slate-200 font-mono">{opp.spreadPct.toFixed(2)}%</p>
                      </div>
                      <div>
                        <p className="text-slate-500">Edge líquido</p>
                        <p className={`font-mono ${opp.netEdgePct > 0.3 ? 'text-emerald-400' : 'text-slate-200'}`}>
                          {opp.netEdgePct.toFixed(2)}%
                        </p>
                      </div>
                      <div>
                        <p className="text-slate-500">Loan</p>
                        <p className="text-slate-200 font-mono">${opp.loanAmountUSD.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-slate-500">Aave fee</p>
                        <p className="text-slate-400 font-mono">${opp.aaveFeeUSD}</p>
                      </div>
                      <div>
                        <p className="text-slate-500">Slippage est.</p>
                        <p className="text-slate-400 font-mono">{opp.slippageEstPct.toFixed(2)}%</p>
                      </div>
                      <div>
                        <p className="text-slate-500">Gas</p>
                        <p className="text-slate-400 font-mono">${opp.gasCostUSD}</p>
                      </div>
                    </div>

                    <div className="border-t border-slate-700/50 pt-2 flex items-center justify-between">
                      <span className="text-xs text-slate-500">Lucro estimado</span>
                      <ProfitBadge profit={opp.netProfitUSD} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* All opportunities table */}
          {opportunities.length > 0 && (
            <div className="bg-slate-800/60 border border-slate-700/50 rounded-xl overflow-hidden">
              <div className="flex items-center justify-between p-3 border-b border-slate-700/50">
                <h3 className="font-semibold text-slate-200 text-sm flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-purple-400" />
                  Todas as oportunidades (24h)
                </h3>
                <button
                  onClick={() => fetchData(true)}
                  disabled={refreshing}
                  className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-300 transition-colors"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
                  Atualizar
                </button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-slate-700/50 bg-slate-900/50">
                      <th className="text-left p-3 text-slate-400 font-medium">Par</th>
                      <th className="text-left p-3 text-slate-400 font-medium">Compra</th>
                      <th className="text-left p-3 text-slate-400 font-medium">Vende</th>
                      <th className="text-right p-3 text-slate-400 font-medium">Spread</th>
                      <th className="text-right p-3 text-slate-400 font-medium">Edge</th>
                      <th className="text-right p-3 text-slate-400 font-medium">Loan</th>
                      <th className="text-right p-3 text-slate-400 font-medium">Lucro</th>
                      <th className="text-center p-3 text-slate-400 font-medium">Conf.</th>
                    </tr>
                  </thead>
                  <tbody>
                    {opportunities.map((opp, i) => (
                      <tr key={i} className="border-b border-slate-700/30 hover:bg-slate-700/20 transition-colors">
                        <td className="p-3">
                          <PairLabel borrow={opp.borrowToken} intermediate={opp.intermediateToken} />
                        </td>
                        <td className="p-3"><DexLabel name={opp.dexBuy} /></td>
                        <td className="p-3"><DexLabel name={opp.dexSell} /></td>
                        <td className="p-3 text-right font-mono text-slate-300">{opp.spreadPct.toFixed(2)}%</td>
                        <td className={`p-3 text-right font-mono ${opp.netEdgePct > 0.3 ? 'text-emerald-400' : 'text-slate-300'}`}>
                          {opp.netEdgePct.toFixed(2)}%
                        </td>
                        <td className="p-3 text-right font-mono text-slate-400">${opp.loanAmountUSD.toLocaleString()}</td>
                        <td className="p-3 text-right"><ProfitBadge profit={opp.netProfitUSD} /></td>
                        <td className="p-3 text-center"><ConfidenceBadge level={opp.confidence} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Empty state */}
          {opportunities.length === 0 && (
            <div className="bg-slate-800/40 border border-slate-700/30 rounded-xl p-8 text-center">
              <Zap className="w-8 h-8 text-slate-600 mx-auto mb-3" />
              <p className="text-slate-400 font-medium">Sem oportunidades detectadas nas últimas 24h</p>
              <p className="text-slate-500 text-sm mt-1">
                O scanner corre automaticamente a cada minuto. Clica em "Forçar Scan" para verificar agora.
              </p>
              <button
                onClick={handleScan}
                disabled={scanning}
                className="mt-4 px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-50"
              >
                {scanning ? 'Scanning...' : 'Scan Agora'}
              </button>
            </div>
          )}

          {/* How it works */}
          <div className="bg-slate-800/30 border border-slate-700/30 rounded-xl p-4 text-xs text-slate-500">
            <p className="font-semibold text-slate-400 mb-1">Como funciona o Flash Loan Arbitrage</p>
            <p>
              1. Empresta do Aave V3 (0.05% fee) · 2. Compra no DEX mais barato (ex: Aerodrome) ·
              3. Vende no DEX mais caro (ex: Uniswap V3) · 4. Devolve o empréstimo na mesma transacção.
              Se o edge não cobrir todas as taxas, a tx reverte — só perdes gas (~$0.03-0.08 na Base).
              Capital necessário: $0. Apenas precisas de ETH para gas na tua wallet.
            </p>
          </div>

          {lastUpdate && (
            <p className="text-xs text-slate-700 text-right">
              Actualizado: {lastUpdate.toLocaleTimeString('pt-BR')} · Atualiza cada 60s
            </p>
          )}
        </>
      )}
    </div>
  )
}
